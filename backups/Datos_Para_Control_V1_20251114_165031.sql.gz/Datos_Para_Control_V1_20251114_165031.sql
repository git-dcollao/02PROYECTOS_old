/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.3-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql_db    Database: proyectosDB
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `actividad_proyecto`
--

DROP TABLE IF EXISTS `actividad_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividad_proyecto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requerimiento_id` int NOT NULL,
  `edt` varchar(50) NOT NULL,
  `nombre_tarea` varchar(500) NOT NULL,
  `nivel_esquema` int NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `duracion` int NOT NULL,
  `dias_corridos` int DEFAULT NULL,
  `predecesoras` text,
  `recursos` text,
  `progreso` decimal(5,2) NOT NULL,
  `datos_adicionales` json DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_actividad_proyecto_edt` (`requerimiento_id`,`edt`),
  KEY `idx_actividad_proyecto_fecha_inicio` (`fecha_inicio`),
  KEY `idx_actividad_proyecto_fecha_fin` (`fecha_fin`),
  KEY `idx_actividad_proyecto_requerimiento` (`requerimiento_id`),
  CONSTRAINT `actividad_proyecto_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actividad_proyecto`
--

LOCK TABLES `actividad_proyecto` WRITE;
/*!40000 ALTER TABLE `actividad_proyecto` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `actividad_proyecto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `actividades_gantt`
--

DROP TABLE IF EXISTS `actividades_gantt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `actividades_gantt` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requerimiento_id` int NOT NULL,
  `edt` varchar(50) NOT NULL,
  `nombre_tarea` varchar(255) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `duracion` int NOT NULL,
  `progreso` float DEFAULT NULL,
  `nivel_esquema` int DEFAULT NULL,
  `predecesoras` varchar(255) DEFAULT NULL,
  `recursos_originales` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_actividades_gantt_req_edt` (`requerimiento_id`,`edt`),
  KEY `idx_actividades_gantt_requerimiento` (`requerimiento_id`),
  KEY `idx_actividades_gantt_edt` (`edt`),
  KEY `idx_actividades_gantt_fecha_inicio` (`fecha_inicio`),
  KEY `idx_actividades_gantt_fecha_fin` (`fecha_fin`),
  CONSTRAINT `actividades_gantt_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `actividades_gantt`
--

LOCK TABLES `actividades_gantt` WRITE;
/*!40000 ALTER TABLE `actividades_gantt` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `actividades_gantt` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `administrador_recinto`
--

DROP TABLE IF EXISTS `administrador_recinto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `administrador_recinto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `administrador_id` int NOT NULL,
  `recinto_id` int NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_administrador_recinto_uc` (`administrador_id`,`recinto_id`),
  KEY `recinto_id` (`recinto_id`),
  CONSTRAINT `administrador_recinto_ibfk_1` FOREIGN KEY (`administrador_id`) REFERENCES `trabajador` (`id`),
  CONSTRAINT `administrador_recinto_ibfk_2` FOREIGN KEY (`recinto_id`) REFERENCES `recinto` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administrador_recinto`
--

LOCK TABLES `administrador_recinto` WRITE;
/*!40000 ALTER TABLE `administrador_recinto` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `administrador_recinto` VALUES
(1,2,4,1,'2025-11-14 13:54:45','2025-11-14 13:54:45'),
(2,2,7,1,'2025-11-14 13:54:45','2025-11-14 13:54:45'),
(3,2,8,1,'2025-11-14 13:54:45','2025-11-14 13:54:45');
/*!40000 ALTER TABLE `administrador_recinto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `area`
--

DROP TABLE IF EXISTS `area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `area` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_area_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `area`
--

LOCK TABLES `area` WRITE;
/*!40000 ALTER TABLE `area` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `area` VALUES
(1,'Administración','Área de administración general',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'SuperAdmin','Primeras personas administradores de la app',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'SECOPLAC','Personas encargadas de SECOPLAC',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'DOM','Personas encargadas de DOM',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'SALUD','Área de gestión de salud',1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `area` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `avance_actividad`
--

DROP TABLE IF EXISTS `avance_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `avance_actividad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requerimiento_id` int NOT NULL,
  `trabajador_id` int NOT NULL,
  `actividad_id` int DEFAULT NULL,
  `porcentaje_asignacion` float DEFAULT NULL,
  `progreso_actual` float DEFAULT NULL,
  `progreso_anterior` float DEFAULT NULL,
  `fecha_registro` date NOT NULL,
  `fecha_creacion` datetime DEFAULT NULL,
  `fecha_actualizacion` datetime DEFAULT NULL,
  `observaciones` text,
  PRIMARY KEY (`id`),
  KEY `requerimiento_id` (`requerimiento_id`),
  KEY `trabajador_id` (`trabajador_id`),
  KEY `actividad_id` (`actividad_id`),
  CONSTRAINT `avance_actividad_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`),
  CONSTRAINT `avance_actividad_ibfk_2` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajador` (`id`),
  CONSTRAINT `avance_actividad_ibfk_3` FOREIGN KEY (`actividad_id`) REFERENCES `actividad_proyecto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avance_actividad`
--

LOCK TABLES `avance_actividad` WRITE;
/*!40000 ALTER TABLE `avance_actividad` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `avance_actividad` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `color` varchar(20) NOT NULL,
  `description` text,
  `display_order` int NOT NULL,
  `icon` varchar(100) NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  `parent_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `categories` VALUES
(1,'Sistema','primary','Páginas del sistema principal y navegación',1,'fas fa-home',1,NULL,'2025-11-03 19:26:39','2025-11-04 17:37:56'),
(2,'Requerimiento','success','Gestión de requerimientos y proyectos',2,'fas fa-clipboard-list',1,NULL,'2025-11-03 19:26:39','2025-11-04 17:37:56'),
(3,'Usuarios','info','Gestión de usuarios y trabajadores',3,'fas fa-users',1,NULL,'2025-11-03 19:26:39','2025-11-04 17:37:56'),
(4,'Configuración','warning','Configuración de catálogos y parámetros del sistema',4,'fas fa-cogs',1,NULL,'2025-11-03 19:26:39','2025-11-04 17:37:56'),
(5,'Administración','danger','Administración avanzada y permisos del sistema',5,'fas fa-shield-alt',1,NULL,'2025-11-03 19:26:39','2025-11-04 17:37:56');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `custom_roles`
--

DROP TABLE IF EXISTS `custom_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `description` text,
  `active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_roles`
--

LOCK TABLES `custom_roles` WRITE;
/*!40000 ALTER TABLE `custom_roles` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `custom_roles` VALUES
(1,'ADMIN','Administrador con permisos amplios pero limitados',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'CONTROL','Control de Proyectos con permisos básicos de control',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'USUARIO','Usuario Operativo con acceso a funcionalidades básicas',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'LECTOR','Usuario con permisos mínimos de solo lectura',1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `custom_roles` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `equipo`
--

DROP TABLE IF EXISTS `equipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipo_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipo`
--

LOCK TABLES `equipo` WRITE;
/*!40000 ALTER TABLE `equipo` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `equipo` VALUES
(1,'Equipo 1',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'Equipo 2',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'Equipo 3',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `equipo` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `equipotrabajo`
--

DROP TABLE IF EXISTS `equipotrabajo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `equipotrabajo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_requerimiento` int NOT NULL,
  `id_trabajador` int NOT NULL,
  `id_especialidad` int NOT NULL,
  `fecha_asignacion` datetime NOT NULL,
  `fecha_desasignacion` datetime DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `observaciones` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_equipo_req_trab_esp` (`id_requerimiento`,`id_trabajador`,`id_especialidad`),
  KEY `idx_equipo_fecha_asignacion` (`fecha_asignacion`),
  KEY `idx_equipo_trabajador` (`id_trabajador`),
  KEY `idx_equipo_especialidad` (`id_especialidad`),
  KEY `idx_equipo_requerimiento` (`id_requerimiento`),
  CONSTRAINT `equipotrabajo_ibfk_1` FOREIGN KEY (`id_requerimiento`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `equipotrabajo_ibfk_2` FOREIGN KEY (`id_trabajador`) REFERENCES `trabajador` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `equipotrabajo_ibfk_3` FOREIGN KEY (`id_especialidad`) REFERENCES `especialidad` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipotrabajo`
--

LOCK TABLES `equipotrabajo` WRITE;
/*!40000 ALTER TABLE `equipotrabajo` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `equipotrabajo` VALUES
(1,4,3,1,'2025-11-14 16:32:44',NULL,1,NULL,'2025-11-14 16:32:44','2025-11-14 16:32:44'),
(2,3,3,1,'2025-11-14 16:41:21',NULL,1,NULL,'2025-11-14 16:41:21','2025-11-14 16:41:21');
/*!40000 ALTER TABLE `equipotrabajo` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `especialidad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_especialidad_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `especialidad` VALUES
(1,'Formulador',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'Arquitecto',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'Ing. Electrico',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'Ing. Civil',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'Ing. Constructor',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `estado`
--

DROP TABLE IF EXISTS `estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `estado` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_estado_nombre` (`nombre`),
  KEY `idx_estado_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estado`
--

LOCK TABLES `estado` WRITE;
/*!40000 ALTER TABLE `estado` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `estado` VALUES
(1,'En Solicitud',NULL,1,'2025-11-03 19:26:39','2025-11-06 15:21:25'),
(2,'Solicitud Aceptada',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'En Desarrollo',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'Desarrollo Aceptado',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'Desarrollo Completado',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(6,'En Ejecución',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(7,'Fin de Ejecución',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(8,'Finalizado',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(9,'Rechazado',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(10,'Cancelado',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `estado` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `fase`
--

DROP TABLE IF EXISTS `fase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fase` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_fase_nombre` (`nombre`),
  KEY `idx_fase_activo` (`activo`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fase`
--

LOCK TABLES `fase` WRITE;
/*!40000 ALTER TABLE `fase` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `fase` VALUES
(1,'Por Definir',NULL,1,'2025-11-06 16:39:34','2025-11-06 16:39:51'),
(2,'Preinversión',NULL,1,'2025-11-06 16:39:59','2025-11-06 16:39:59'),
(3,'Inversión',NULL,1,'2025-11-06 16:40:05','2025-11-06 16:40:05'),
(4,'Operación',NULL,1,'2025-11-06 16:40:09','2025-11-06 16:40:09');
/*!40000 ALTER TABLE `fase` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `financiamiento`
--

DROP TABLE IF EXISTS `financiamiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `financiamiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_financiamiento_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `financiamiento`
--

LOCK TABLES `financiamiento` WRITE;
/*!40000 ALTER TABLE `financiamiento` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `financiamiento` VALUES
(1,'Por Definir','Aún no se define el financiamiento',1,'2025-11-06 19:28:13','2025-11-06 19:28:13'),
(2,'Gobierno Regional','Gobierno regional financia el proyecto',1,'2025-11-06 19:28:30','2025-11-06 19:28:30'),
(3,'MINSAL','Ministerio de Salud financia el proyecto',1,'2025-11-06 19:28:42','2025-11-06 19:28:42'),
(4,'DEPSA','Departamento de Salud financia el proyecto',1,'2025-11-06 19:29:04','2025-11-06 19:29:04'),
(5,'SUBDERE','Subsecretaría de Desarrollo Regional financia el proyecto',1,'2025-11-06 19:29:19','2025-11-06 19:29:19'),
(6,'MUNICIPAL','Municipalidad financia el proyecto',1,'2025-11-06 19:29:31','2025-11-06 19:29:31');
/*!40000 ALTER TABLE `financiamiento` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `gantt_archivo`
--

DROP TABLE IF EXISTS `gantt_archivo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gantt_archivo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_requerimiento` int NOT NULL,
  `archivo` blob NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `tipo_archivo` varchar(50) NOT NULL,
  `tamano_archivo` int NOT NULL,
  `fecha_subida` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gantt_requerimiento` (`id_requerimiento`),
  CONSTRAINT `gantt_archivo_ibfk_1` FOREIGN KEY (`id_requerimiento`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gantt_archivo`
--

LOCK TABLES `gantt_archivo` WRITE;
/*!40000 ALTER TABLE `gantt_archivo` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `gantt_archivo` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `grupo`
--

DROP TABLE IF EXISTS `grupo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `grupo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_grupo_nombre` (`nombre`),
  KEY `idx_grupo_activo` (`activo`),
  KEY `idx_grupo_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `grupo`
--

LOCK TABLES `grupo` WRITE;
/*!40000 ALTER TABLE `grupo` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `grupo` VALUES
(1,'Grupo 1',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'Grupo 2',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'Grupo 3',1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `grupo` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `historial_avance_actividad`
--

DROP TABLE IF EXISTS `historial_avance_actividad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_avance_actividad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requerimiento_id` int NOT NULL,
  `trabajador_id` int NOT NULL,
  `actividad_id` int NOT NULL,
  `progreso_anterior` float NOT NULL,
  `progreso_nuevo` float NOT NULL,
  `diferencia` float NOT NULL,
  `comentarios` text,
  `fecha_cambio` datetime NOT NULL,
  `sesion_guardado` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `requerimiento_id` (`requerimiento_id`),
  KEY `trabajador_id` (`trabajador_id`),
  KEY `actividad_id` (`actividad_id`),
  CONSTRAINT `historial_avance_actividad_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`),
  CONSTRAINT `historial_avance_actividad_ibfk_2` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajador` (`id`),
  CONSTRAINT `historial_avance_actividad_ibfk_3` FOREIGN KEY (`actividad_id`) REFERENCES `actividad_proyecto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_avance_actividad`
--

LOCK TABLES `historial_avance_actividad` WRITE;
/*!40000 ALTER TABLE `historial_avance_actividad` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `historial_avance_actividad` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `historial_control`
--

DROP TABLE IF EXISTS `historial_control`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `historial_control` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sesion_subida` varchar(50) NOT NULL,
  `fecha_operacion` datetime NOT NULL,
  `nombre_archivo` varchar(255) NOT NULL,
  `actividad_id` int NOT NULL,
  `requerimiento_id` int NOT NULL,
  `tipo_operacion` varchar(20) NOT NULL,
  `datos_anteriores` json DEFAULT NULL,
  `datos_nuevos` json NOT NULL,
  `fila_excel` int NOT NULL,
  `comentarios` text,
  PRIMARY KEY (`id`),
  KEY `requerimiento_id` (`requerimiento_id`),
  KEY `idx_historial_control_sesion` (`sesion_subida`),
  KEY `idx_historial_control_fecha` (`fecha_operacion`),
  KEY `idx_historial_control_actividad` (`actividad_id`),
  CONSTRAINT `historial_control_ibfk_1` FOREIGN KEY (`actividad_id`) REFERENCES `actividad_proyecto` (`id`),
  CONSTRAINT `historial_control_ibfk_2` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historial_control`
--

LOCK TABLES `historial_control` WRITE;
/*!40000 ALTER TABLE `historial_control` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `historial_control` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `menu_configuration`
--

DROP TABLE IF EXISTS `menu_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sidebar_collapsed` tinyint(1) NOT NULL,
  `theme` varchar(20) NOT NULL,
  `menu_style` varchar(20) NOT NULL,
  `show_icons` tinyint(1) NOT NULL,
  `show_badges` tinyint(1) NOT NULL,
  `custom_css` text,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_configuration`
--

LOCK TABLES `menu_configuration` WRITE;
/*!40000 ALTER TABLE `menu_configuration` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `menu_configuration` VALUES
(1,0,'light','vertical',1,1,NULL,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `menu_configuration` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `observacion_requerimiento`
--

DROP TABLE IF EXISTS `observacion_requerimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `observacion_requerimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_requerimiento` int NOT NULL,
  `observacion` text NOT NULL,
  `fecha_registro` datetime NOT NULL,
  `id_usuario` int NOT NULL,
  `pagina_origen` varchar(100) NOT NULL,
  `tipo_evento` enum('requerimiento','aceptado','rechazado','completado','proyecto_aceptado','proyecto_rechazado','obs_control','finalizado') NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_observacion_fecha` (`fecha_registro`),
  KEY `idx_observacion_usuario` (`id_usuario`),
  KEY `idx_observacion_tipo` (`tipo_evento`),
  KEY `idx_observacion_requerimiento` (`id_requerimiento`),
  CONSTRAINT `observacion_requerimiento_ibfk_1` FOREIGN KEY (`id_requerimiento`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `observacion_requerimiento_ibfk_2` FOREIGN KEY (`id_usuario`) REFERENCES `trabajador` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `observacion_requerimiento`
--

LOCK TABLES `observacion_requerimiento` WRITE;
/*!40000 ALTER TABLE `observacion_requerimiento` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `observacion_requerimiento` VALUES
(1,4,'REQUERIMIENTO ACEPTADO: Prueba 1 aceptado','2025-11-14 16:32:11',2,'requerimiento-aceptar','aceptado','2025-11-14 16:32:12','2025-11-14 16:32:12'),
(2,4,'Prueba 1 aceptado completado','2025-11-14 16:33:19',2,'requerimiento_completar','completado','2025-11-14 16:33:19','2025-11-14 16:33:19'),
(3,4,'Prueba 1 aceptado como proyecto','2025-11-14 16:40:52',2,'proyectos_aceptar','finalizado','2025-11-14 16:40:52','2025-11-14 16:40:52'),
(4,3,'Prueba proyecto desarrollo aceptado','2025-11-14 16:44:13',2,'proyectos_aceptar','finalizado','2025-11-14 16:44:13','2025-11-14 16:44:13');
/*!40000 ALTER TABLE `observacion_requerimiento` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `page_permissions`
--

DROP TABLE IF EXISTS `page_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `page_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `page_id` int NOT NULL,
  `system_role` enum('SUPERADMIN') DEFAULT NULL,
  `custom_role_id` int DEFAULT NULL,
  `role_name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_page_permission_name` (`page_id`,`role_name`),
  KEY `custom_role_id` (`custom_role_id`),
  CONSTRAINT `page_permissions_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`),
  CONSTRAINT `page_permissions_ibfk_2` FOREIGN KEY (`custom_role_id`) REFERENCES `custom_roles` (`id`),
  CONSTRAINT `ck_permission_role_type` CHECK ((((`system_role` is not null) and (`custom_role_id` is null)) or ((`system_role` is null) and (`custom_role_id` is not null))))
) ENGINE=InnoDB AUTO_INCREMENT=263 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `page_permissions`
--

LOCK TABLES `page_permissions` WRITE;
/*!40000 ALTER TABLE `page_permissions` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `page_permissions` VALUES
(164,1,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(165,21,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(166,42,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(167,43,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(168,27,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(169,28,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(170,29,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(171,30,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(172,32,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(173,33,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(174,34,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(175,36,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(176,8,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(177,9,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(178,10,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(179,11,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(180,12,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(181,13,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(182,14,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(183,15,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(184,16,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(185,17,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(186,18,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(187,19,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(188,20,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(189,26,NULL,1,'ADMIN','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(191,1,NULL,2,'CONTROL','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(192,33,NULL,2,'CONTROL','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(193,26,NULL,2,'CONTROL','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(195,1,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(196,27,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(197,4,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(198,6,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(199,7,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(200,34,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(201,8,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(202,9,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(203,14,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(204,15,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(205,16,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(206,17,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(207,18,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(208,26,NULL,3,'USUARIO','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(210,1,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(211,4,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(212,6,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(213,7,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(214,8,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(215,9,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(216,14,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(217,15,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(218,16,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(219,17,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(220,18,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(221,26,NULL,4,'LECTOR','2025-11-06 16:09:19','2025-11-06 16:09:19'),
(223,1,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(228,8,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(229,9,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(230,10,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(231,11,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(232,12,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(233,13,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(234,14,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(235,15,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(236,16,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(237,17,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(238,18,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(239,19,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(240,20,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(241,21,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(242,26,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(243,27,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(244,28,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(245,29,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(246,30,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(247,31,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(248,32,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(249,33,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(250,34,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(251,35,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(252,36,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(253,37,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(257,42,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(258,43,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 17:26:47','2025-11-06 17:26:47'),
(259,35,NULL,1,'ADMIN','2025-11-06 17:30:21','2025-11-06 17:30:21'),
(260,37,NULL,1,'ADMIN','2025-11-06 17:30:22','2025-11-06 17:30:22'),
(262,44,'SUPERADMIN',NULL,'SUPERADMIN','2025-11-06 20:49:07','2025-11-06 20:49:07');
/*!40000 ALTER TABLE `page_permissions` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `route` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text,
  `category_id` int NOT NULL,
  `template_path` varchar(300) DEFAULT NULL,
  `active` tinyint(1) NOT NULL,
  `display_order` int NOT NULL,
  `icon` varchar(100) NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  `parent_page_id` int DEFAULT NULL,
  `menu_group` varchar(100) DEFAULT NULL,
  `external_url` varchar(500) DEFAULT NULL,
  `target_blank` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `route` (`route`),
  KEY `category_id` (`category_id`),
  KEY `parent_page_id` (`parent_page_id`),
  CONSTRAINT `pages_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `pages_ibfk_2` FOREIGN KEY (`parent_page_id`) REFERENCES `pages` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `pages` VALUES
(1,'/','Inicio','Página Inicio',1,'',1,1,'fas fa-home',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-06 12:09:53'),
(3,'/health','Estado del Sistema','Estado y salud del sistema',1,NULL,1,3,'fas fa-heartbeat',0,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(4,'/projects','Lista de Proyectos','Ver todos los proyectos',2,NULL,1,1,'fas fa-list',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(5,'/projects/create','Crear Proyecto','Crear nuevo proyecto',2,NULL,1,2,'fas fa-plus',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(6,'/actividades','Actividades','Gestión de actividades de proyecto',2,NULL,1,3,'fas fa-tasks',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(7,'/gantt','Diagrama de Gantt','Visualización de cronogramas',2,NULL,1,4,'fas fa-chart-line',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(8,'/estados','Estados','Gestión de estados de proyecto',4,NULL,1,1,'fas fa-flag',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(9,'/prioridades','Prioridades','Gestión de prioridades',4,NULL,1,2,'fas fa-exclamation-triangle',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(10,'/fases','Fases','Gestión de fases de proyecto',4,NULL,1,3,'fas fa-layer-group',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(11,'/tipologias','Tipologías','Gestión de tipologías',4,NULL,1,4,'fas fa-tags',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(12,'/financiamientos','Financiamientos','Gestión de tipos de financiamiento',4,NULL,1,5,'fas fa-money-bill-wave',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(13,'/tipoproyectos','Tipos de Proyecto','Gestión de tipos de proyecto',4,NULL,1,6,'fas fa-project-diagram',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(14,'/sectores','Sectores','Gestión de sectores',4,NULL,1,7,'fas fa-building',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(15,'/tiposrecintos','Tipos de Recinto','Gestión de tipos de recinto',4,NULL,1,8,'fas fa-home',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(16,'/recintos','Recintos','Gestión de recintos',4,NULL,1,9,'fas fa-map-marker-alt',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(17,'/equipos','Equipos','Gestión de equipos de trabajo',4,NULL,1,10,'fas fa-users-cog',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(18,'/especialidades','Especialidades','Gestión de especialidades',4,NULL,1,11,'fas fa-graduation-cap',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(19,'/areas','Áreas','Gestión de áreas organizacionales',4,NULL,1,12,'fas fa-sitemap',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(20,'/grupos','Grupos','Gestión de grupos de trabajo',4,NULL,1,13,'fas fa-layer-group',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(21,'/trabajadores','Trabajadores','Gestión de usuarios del sistema',3,NULL,1,1,'fas fa-users',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(22,'/auth/login','Iniciar Sesión','Página de inicio de sesión',3,NULL,1,2,'fas fa-sign-in-alt',0,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(23,'/auth/logout','Cerrar Sesión','Página Cerrar Sesión',3,'',1,3,'fas fa-sign-out-alt',0,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-06 20:44:49'),
(25,'/profile/edit','Editar Mi Perfil','Editar información personal del perfil',3,NULL,1,5,'fas fa-user-edit',0,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(26,'/auth/mi-perfil','Mi Perfil','Página Mi Perfil',3,'',1,6,'fas fa-id-card',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(27,'/requerimientos','Requerimientos','Gestión de requerimientos',2,NULL,1,1,'fas fa-clipboard-list',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(28,'/requerimientos_aceptar','Requerimientos Aceptar','Aceptar requerimientos',2,NULL,1,2,'fas fa-check-circle',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(29,'/requerimientos_completar','Requerimientos Completar','Completar requerimientos',2,NULL,1,3,'fas fa-clipboard-check',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(30,'/proyectos_aceptar','Proyecto Aceptar','Aceptar proyectos',2,NULL,1,4,'fas fa-thumbs-up',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(31,'/proyectos_completar','Proyectos Completar OLD','Completar proyectos (versión anterior)',2,NULL,1,5,'fas fa-archive',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(32,'/proyecto-llenar','Proyectos Completar','Completar información de proyectos',2,NULL,1,6,'fas fa-edit',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(33,'/control_actividades','Controles','Control de actividades',2,NULL,1,7,'fas fa-clipboard-list',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(34,'/avance-actividades','Avance Actividades','Seguimiento de avance de actividades',2,NULL,1,8,'fas fa-chart-line',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(35,'/avance-actividades-all','Avance Actividades - Todos','Seguimiento de avance de actividades (todos los proyectos)',2,NULL,1,9,'fas fa-chart-area',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(36,'/historial-avances','Historial Avances','Historial de avances registrados',2,NULL,1,10,'fas fa-history',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-10-21 13:28:06'),
(37,'/permissions/','Gestión de Permisos','Administrar permisos de usuarios',5,NULL,1,1,'fas fa-shield-alt',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(38,'/admin/config','Administración','Configurar parámetros del sistema',5,NULL,1,2,'fas fa-cogs',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(39,'/admin/logs','Administración','Ver logs y auditoría',5,NULL,1,3,'fas fa-file-alt',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(41,'/admin/maintenance','Administración','Tareas de mantenimiento del sistema',5,NULL,1,5,'fas fa-tools',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(42,'/gestion-administradores','Gestión de Administradores','Asignar recintos específicos a cada administrador',5,NULL,1,6,'fas fa-users-cog',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(43,'/gestion-usuarios','Gestión de Usuarios por Recinto','Asignar recintos adicionales a trabajadores de mis recintos',5,NULL,1,7,'fas fa-users',1,NULL,NULL,NULL,0,'2025-10-21 13:28:06','2025-11-04 17:30:24'),
(44,'/admin/gestion_backup','Gestión de Backup','Página Gestión de Backup',5,'/admin/gestion_backup.html',1,0,'fas fa-file',1,NULL,NULL,NULL,0,'2025-11-06 20:49:07','2025-11-06 20:49:07');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `prioridad`
--

DROP TABLE IF EXISTS `prioridad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `prioridad` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `descripcion` text,
  `urgencia` tinyint(1) NOT NULL,
  `importancia` tinyint(1) NOT NULL,
  `cuadrante` int NOT NULL,
  `color` varchar(7) NOT NULL,
  `orden` int NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_prioridad_nombre` (`nombre`),
  KEY `idx_prioridad_orden` (`orden`),
  KEY `idx_prioridad_cuadrante` (`cuadrante`),
  CONSTRAINT `ck_prioridad_cuadrante` CHECK (((`cuadrante` >= 1) and (`cuadrante` <= 4))),
  CONSTRAINT `ck_prioridad_orden` CHECK ((`orden` > 0))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prioridad`
--

LOCK TABLES `prioridad` WRITE;
/*!40000 ALTER TABLE `prioridad` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `prioridad` VALUES
(1,'Urgente e Importante','Crisis, emergencias, problemas urgentes con fechas límite',1,1,1,'#dc3545',1,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'Importante, No Urgente','Planificación, prevención, desarrollo personal, nuevas oportunidades',0,1,2,'#ffc107',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'Urgente, No Importante','Interrupciones, algunas llamadas, correos, reuniones',1,0,3,'#fd7e14',3,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'No Urgente, No Importante','Trivialidades, pérdidas de tiempo, actividades placenteras',0,0,4,'#6c757d',4,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `prioridad` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `recinto`
--

DROP TABLE IF EXISTS `recinto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recinto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `id_tiporecinto` int NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_recinto_nombre_tiporecinto` (`nombre`,`id_tiporecinto`),
  KEY `idx_recinto_activo` (`activo`),
  KEY `idx_recinto_tiporecinto` (`id_tiporecinto`),
  CONSTRAINT `recinto_ibfk_1` FOREIGN KEY (`id_tiporecinto`) REFERENCES `tiporecinto` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recinto`
--

LOCK TABLES `recinto` WRITE;
/*!40000 ALTER TABLE `recinto` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `recinto` VALUES
(1,'CESFAM La Tortuga','Centro de Salud Familiar La Tortuga',1,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'CECOSF El Boro','Centro Comunitario El Boro',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'SAPU Dr. Héctor Reyno','Servicio de Atención Primaria',3,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'Oficinas DEPSA','Oficinas del Departamento de Salud',5,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(7,'Oficinas SECOPLAC','Oficinas del Secretaría Comunal de Planificación y Coordinación',5,1,'2025-11-06 20:35:41','2025-11-06 20:35:41'),
(8,'Oficina DOM','Oficinas de la Dirección de Obras Municipales ',5,1,'2025-11-06 20:36:27','2025-11-06 20:36:27');
/*!40000 ALTER TABLE `recinto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `recursos_trabajador`
--

DROP TABLE IF EXISTS `recursos_trabajador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recursos_trabajador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `requerimiento_id` int NOT NULL,
  `actividad_gantt_id` int NOT NULL,
  `edt` varchar(50) NOT NULL,
  `fecha_asignacion` datetime DEFAULT NULL,
  `recurso` varchar(255) NOT NULL,
  `id_trabajador` int NOT NULL,
  `porcentaje_asignacion` float DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_recurso_trabajador_requerimiento` (`requerimiento_id`),
  KEY `idx_recurso_trabajador_trabajador` (`id_trabajador`),
  KEY `idx_recurso_trabajador_unique` (`actividad_gantt_id`,`id_trabajador`),
  KEY `idx_recurso_trabajador_edt` (`edt`),
  CONSTRAINT `recursos_trabajador_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recursos_trabajador_ibfk_2` FOREIGN KEY (`actividad_gantt_id`) REFERENCES `actividades_gantt` (`id`) ON DELETE CASCADE,
  CONSTRAINT `recursos_trabajador_ibfk_3` FOREIGN KEY (`id_trabajador`) REFERENCES `trabajador` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recursos_trabajador`
--

LOCK TABLES `recursos_trabajador` WRITE;
/*!40000 ALTER TABLE `recursos_trabajador` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `recursos_trabajador` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `requerimiento`
--

DROP TABLE IF EXISTS `requerimiento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requerimiento` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `fecha` datetime NOT NULL,
  `descripcion` text,
  `observacion` text,
  `id_sector` int NOT NULL,
  `id_tiporecinto` int NOT NULL,
  `id_recinto` int NOT NULL,
  `id_estado` int NOT NULL,
  `id_prioridad` int DEFAULT NULL,
  `id_grupo` int DEFAULT NULL,
  `id_area` int DEFAULT NULL,
  `fecha_aceptacion` datetime DEFAULT NULL,
  `id_tipologia` int DEFAULT NULL,
  `id_financiamiento` int DEFAULT NULL,
  `id_tipoproyecto` int DEFAULT NULL,
  `proyecto` varchar(50) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_tiporecinto` (`id_tiporecinto`),
  KEY `id_recinto` (`id_recinto`),
  KEY `id_grupo` (`id_grupo`),
  KEY `id_area` (`id_area`),
  KEY `id_tipologia` (`id_tipologia`),
  KEY `id_financiamiento` (`id_financiamiento`),
  KEY `id_tipoproyecto` (`id_tipoproyecto`),
  KEY `idx_requerimiento_estado` (`id_estado`),
  KEY `idx_requerimiento_fecha` (`fecha`),
  KEY `idx_requerimiento_prioridad` (`id_prioridad`),
  KEY `idx_requerimiento_sector` (`id_sector`),
  CONSTRAINT `requerimiento_ibfk_1` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_10` FOREIGN KEY (`id_tipoproyecto`) REFERENCES `tipoproyecto` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_2` FOREIGN KEY (`id_tiporecinto`) REFERENCES `tiporecinto` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_3` FOREIGN KEY (`id_recinto`) REFERENCES `recinto` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_4` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_5` FOREIGN KEY (`id_prioridad`) REFERENCES `prioridad` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_6` FOREIGN KEY (`id_grupo`) REFERENCES `grupo` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_7` FOREIGN KEY (`id_area`) REFERENCES `area` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_8` FOREIGN KEY (`id_tipologia`) REFERENCES `tipologia` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `requerimiento_ibfk_9` FOREIGN KEY (`id_financiamiento`) REFERENCES `financiamiento` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requerimiento`
--

LOCK TABLES `requerimiento` WRITE;
/*!40000 ALTER TABLE `requerimiento` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `requerimiento` VALUES
(1,'PROYECTO PRUEBA 1','2025-01-15 00:00:00','Proyecto de prueba para el sistema','Solo prueba 1',1,1,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'PROYECTO PRUEBA 2','2025-01-16 00:00:00','Segundo proyecto de prueba','Solo prueba 2',2,2,2,1,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'PROYECTO EN DESARROLLO','2025-01-14 00:00:00','Proyecto que ya fue aceptado y está en desarrollo','Prueba proyecto desarrollo aceptado',1,5,7,4,1,1,NULL,'2025-01-15 00:00:00',6,2,3,NULL,1,'2025-11-03 19:26:39','2025-11-14 16:44:13'),
(4,'Prueba 1','2025-11-14 00:00:00','Prueba 1','Prueba 1 aceptado como proyecto',1,5,7,4,1,1,NULL,NULL,2,2,3,NULL,1,'2025-11-14 16:31:48','2025-11-14 16:40:52');
/*!40000 ALTER TABLE `requerimiento` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `requerimiento_trabajador_especialidad`
--

DROP TABLE IF EXISTS `requerimiento_trabajador_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `requerimiento_trabajador_especialidad` (
  `requerimiento_id` int NOT NULL,
  `trabajador_id` int NOT NULL,
  `especialidad_id` int NOT NULL,
  `fecha_asignacion` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`requerimiento_id`,`trabajador_id`,`especialidad_id`),
  KEY `trabajador_id` (`trabajador_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `requerimiento_trabajador_especialidad_ibfk_1` FOREIGN KEY (`requerimiento_id`) REFERENCES `requerimiento` (`id`) ON DELETE CASCADE,
  CONSTRAINT `requerimiento_trabajador_especialidad_ibfk_2` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajador` (`id`) ON DELETE CASCADE,
  CONSTRAINT `requerimiento_trabajador_especialidad_ibfk_3` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `requerimiento_trabajador_especialidad`
--

LOCK TABLES `requerimiento_trabajador_especialidad` WRITE;
/*!40000 ALTER TABLE `requerimiento_trabajador_especialidad` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `requerimiento_trabajador_especialidad` VALUES
(3,3,1,'2025-11-14 16:43:10',1),
(4,3,1,'2025-11-14 16:33:19',1);
/*!40000 ALTER TABLE `requerimiento_trabajador_especialidad` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sector`
--

DROP TABLE IF EXISTS `sector`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sector` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_sector_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sector`
--

LOCK TABLES `sector` WRITE;
/*!40000 ALTER TABLE `sector` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sector` VALUES
(1,'MUNICIPAL',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'SALUD',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'CEMENTERIO',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'EDUCACION',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'OTRO',NULL,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `sector` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tipologia`
--

DROP TABLE IF EXISTS `tipologia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipologia` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `nombrecorto` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_fase` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tipologia_nombre` (`nombre`),
  KEY `idx_tipologia_activo` (`activo`),
  KEY `fk_tipologia_fase` (`id_fase`),
  CONSTRAINT `fk_tipologia_fase` FOREIGN KEY (`id_fase`) REFERENCES `fase` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipologia`
--

LOCK TABLES `tipologia` WRITE;
/*!40000 ALTER TABLE `tipologia` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tipologia` VALUES
(1,'Por definir','Por definir',NULL,1,'2025-11-06 18:48:58','2025-11-06 18:49:29',1),
(2,'Estudios Básicos - PreInv','Estudios Básicos - PreInv',NULL,1,'2025-11-06 18:50:02','2025-11-06 18:50:02',2),
(3,'Programa de Inversión - PreInv','Prog_Inv-PreInv',NULL,1,'2025-11-06 18:50:31','2025-11-06 18:50:31',2),
(4,'Proyecto de Inversión - PreInv','Proy_Inv-PreInv',NULL,1,'2025-11-06 18:51:14','2025-11-06 18:51:14',2),
(5,'Estudios Básicos - Inv','EB-Inv',NULL,1,'2025-11-06 18:51:40','2025-11-06 18:51:40',3),
(6,'Programa de Inversión - Inv','Prog_Inv-Inv',NULL,1,'2025-11-06 18:52:20','2025-11-06 18:52:20',3),
(7,'Proyecto de Inversión - Inv','Proy_Inv-Inv',NULL,1,'2025-11-06 18:52:53','2025-11-06 18:52:53',3),
(8,'Proyecto de Inversión - Op','Proy_Inv-Op',NULL,1,'2025-11-06 18:53:14','2025-11-06 18:53:14',4);
/*!40000 ALTER TABLE `tipologia` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tipoproyecto`
--

DROP TABLE IF EXISTS `tipoproyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipoproyecto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `nombrecorto` varchar(50) DEFAULT NULL,
  `descripcion` text,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tipoproyecto_nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipoproyecto`
--

LOCK TABLES `tipoproyecto` WRITE;
/*!40000 ALTER TABLE `tipoproyecto` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tipoproyecto` VALUES
(1,'Por Definir','Por Definir','Fondos por definir',1,'2025-11-03 19:26:39','2025-11-06 15:27:47'),
(2,'PMI','PMI','Fondo para Proyectos de Mejoramiento Integral',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'AGL','AGL','Fondo de Ampliación y Generación de Lugares',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'FNDR - Circular 33','FNDR-C33','Fondo Nacional de Desarrollo Regional - Circular 33',1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'FNDR - Circular 31','FNDR-C31','Fondo Nacional de Desarrollo Regional - Circular 31',1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `tipoproyecto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `tiporecinto`
--

DROP TABLE IF EXISTS `tiporecinto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tiporecinto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `descripcion` text,
  `id_sector` int NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_tiporecinto_nombre_sector` (`nombre`,`id_sector`),
  KEY `idx_tiporecinto_sector` (`id_sector`),
  KEY `idx_tiporecinto_activo` (`activo`),
  CONSTRAINT `tiporecinto_ibfk_1` FOREIGN KEY (`id_sector`) REFERENCES `sector` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tiporecinto`
--

LOCK TABLES `tiporecinto` WRITE;
/*!40000 ALTER TABLE `tiporecinto` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `tiporecinto` VALUES
(1,'CESFAM','Centro de Salud Familiar',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(2,'CECOSF','Centro Comunitario de Salud Familiar',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(3,'SAPU','Servicio de Atención Primaria de Urgencia',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(4,'SAR','Servicio de Alta Resolución',2,1,'2025-11-03 19:26:39','2025-11-03 19:26:39'),
(5,'ED. CONSISTORIAL','Edificio Consistorial',1,1,'2025-11-03 19:26:39','2025-11-03 19:26:39');
/*!40000 ALTER TABLE `tiporecinto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `trabajador`
--

DROP TABLE IF EXISTS `trabajador`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trabajador` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `rut` varchar(12) DEFAULT NULL,
  `profesion` varchar(255) DEFAULT NULL,
  `nombrecorto` varchar(50) DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL,
  `rol` enum('SUPERADMIN') DEFAULT NULL,
  `custom_role_id` int DEFAULT NULL,
  `ultimo_acceso` datetime DEFAULT NULL,
  `intentos_fallidos` int NOT NULL,
  `bloqueado_hasta` datetime DEFAULT NULL,
  `area_id` int DEFAULT NULL,
  `sector_id` int DEFAULT NULL,
  `recinto_id` int DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_trabajador_nombre` (`nombre`),
  UNIQUE KEY `uq_trabajador_email` (`email`),
  UNIQUE KEY `uq_trabajador_rut` (`rut`),
  UNIQUE KEY `email` (`email`),
  KEY `custom_role_id` (`custom_role_id`),
  KEY `sector_id` (`sector_id`),
  KEY `recinto_id` (`recinto_id`),
  KEY `idx_trabajador_activo` (`activo`),
  KEY `idx_trabajador_profesion` (`profesion`),
  KEY `idx_trabajador_email` (`email`),
  KEY `idx_trabajador_area` (`area_id`),
  KEY `idx_trabajador_rut` (`rut`),
  KEY `idx_trabajador_rol` (`rol`),
  CONSTRAINT `trabajador_ibfk_1` FOREIGN KEY (`custom_role_id`) REFERENCES `custom_roles` (`id`),
  CONSTRAINT `trabajador_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trabajador_ibfk_3` FOREIGN KEY (`sector_id`) REFERENCES `sector` (`id`) ON DELETE SET NULL,
  CONSTRAINT `trabajador_ibfk_4` FOREIGN KEY (`recinto_id`) REFERENCES `recinto` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trabajador`
--

LOCK TABLES `trabajador` WRITE;
/*!40000 ALTER TABLE `trabajador` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `trabajador` VALUES
(1,'Admin Sistema','11111111-1','Administrador Sistema','admin','$argon2id$v=19$m=65536,t=3,p=4$C5FBF+okppFcnIaDqFw/JQ$y5uHKx94v9UiOlV0SfqAqNpHIqHu/ySvMXW33yOlPZY','admin@sistema.local',NULL,1,'SUPERADMIN',NULL,'2025-11-14 16:49:54',2,NULL,NULL,1,NULL,'2025-11-03 19:26:39','2025-11-14 16:49:54'),
(2,'Administrador L1','22222222-2','Administrador','admingen','$argon2id$v=19$m=65536,t=3,p=4$dltTeHg4NjfKJp6WtyYbKw$8E9ayD5OC8mHi22gP5l8gwjGA+bLgdZ6+DqQLBoIFyw','administrador@sistema.local',NULL,1,NULL,1,'2025-11-14 16:04:26',2,NULL,NULL,1,7,'2025-11-03 19:26:39','2025-11-14 16:04:26'),
(3,'Control de Proyectos','33333333-3','Jefe de Control','control','$argon2id$v=19$m=65536,t=3,p=4$OjZtkQfdDGqjgDJQhvX1Rg$42zyKRti8Hz9wa5AzSTL0PEHYqr3PNbsR9JGLiIF6PU','control@sistema.local',NULL,1,NULL,2,NULL,0,NULL,NULL,2,1,'2025-11-03 19:26:39','2025-11-13 20:40:08'),
(4,'Usuario Operativo','44444444-4','Especialista','usuario','$argon2id$v=19$m=65536,t=3,p=4$zPpBek3PZAtm75AMl4wYOg$BbRRBTQOwsVamzl/TxEe2n0IjLOEZr7dTsgsefEQOiE','usuario@sistema.local',NULL,1,NULL,3,NULL,0,NULL,NULL,2,1,'2025-11-03 19:26:39','2025-11-13 20:40:08'),
(5,'Solicitante Externo','55555555-5','Solicitante','solicit','$argon2id$v=19$m=65536,t=3,p=4$OCX4Zr/dCNJsXJVjK4BmTg$DCL56PKe2pBobktApM5xgiKGn8RmG/05ct2me3sjqBQ','solicitante@sistema.local',NULL,1,NULL,1,NULL,0,NULL,NULL,2,1,'2025-11-03 19:26:39','2025-11-13 20:40:08'),
(6,'Lector del Sistema','66666666-6','Consultor','lector','$argon2id$v=19$m=65536,t=3,p=4$5BaBq5i+sz5RTVc+zy8JTQ$+7HSf72+kFTcuKp2TRks7PCujOMCQJZVlqYSPsp8/V0','lector@sistema.local',NULL,1,NULL,4,NULL,0,NULL,NULL,2,1,'2025-11-03 19:26:39','2025-11-13 20:40:08');
/*!40000 ALTER TABLE `trabajador` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `trabajador_areas`
--

DROP TABLE IF EXISTS `trabajador_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trabajador_areas` (
  `trabajador_id` int NOT NULL,
  `area_id` int NOT NULL,
  `fecha_asignacion` datetime NOT NULL,
  `activo` tinyint(1) NOT NULL,
  PRIMARY KEY (`trabajador_id`,`area_id`),
  KEY `idx_trabajador_areas_trabajador` (`trabajador_id`),
  KEY `idx_trabajador_areas_area` (`area_id`),
  KEY `idx_trabajador_areas_activo` (`activo`),
  CONSTRAINT `trabajador_areas_ibfk_1` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajador` (`id`) ON DELETE CASCADE,
  CONSTRAINT `trabajador_areas_ibfk_2` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trabajador_areas`
--

LOCK TABLES `trabajador_areas` WRITE;
/*!40000 ALTER TABLE `trabajador_areas` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `trabajador_areas` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `trabajador_recinto`
--

DROP TABLE IF EXISTS `trabajador_recinto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trabajador_recinto` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trabajador_id` int NOT NULL,
  `recinto_id` int NOT NULL,
  `activo` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_trabajador_recinto_uc` (`trabajador_id`,`recinto_id`),
  KEY `recinto_id` (`recinto_id`),
  CONSTRAINT `trabajador_recinto_ibfk_1` FOREIGN KEY (`trabajador_id`) REFERENCES `trabajador` (`id`),
  CONSTRAINT `trabajador_recinto_ibfk_2` FOREIGN KEY (`recinto_id`) REFERENCES `recinto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trabajador_recinto`
--

LOCK TABLES `trabajador_recinto` WRITE;
/*!40000 ALTER TABLE `trabajador_recinto` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `trabajador_recinto` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping routines for database 'proyectosDB'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-11-14 16:50:31
